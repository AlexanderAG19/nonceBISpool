noncepool_miner
------------------------------
noncepool.com  bismuth miner
------------------------------


The heavy3.bin file is created if it does not exist.

If the optimize.txt file does not exist, a quick optimization scan is run on startup.
Setting --worksize or --batch will override this quick scan.
A full (slower) scan can be performed by running --opt



Usage:
	./noncepool_miner options address workername

Options:
	--worksize		set worksize (64-1024)
	--batch			set batch size (128 - 32768)
	--opt			run full optimization for worksize and batch values
	--skip-gpu		comma separated list of gpus to skip ( example: 0,1,2,3)
	-p				set port number for ccminer stats (default 4028)


