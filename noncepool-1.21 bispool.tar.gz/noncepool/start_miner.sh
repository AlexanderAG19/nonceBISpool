#!/bin/bash

USENVIDIA=0
USEAMD=0


AMDCARDS=$(./checkcards -q --amd)
AMDCARDS=$?

#AMDCARDS=0
NVIDIACARDS=$(./checkcards -q --nvidia)
NVIDIACARDS=$?

echo "Detected $AMDCARDS AMD GPU and $NVIDIACARDS NVIDIA GPU"

if [ "$AMDCARDS" -gt "0" ];then USEAMD=1; else echo "No AMD cards detected"; fi
if [ "$NVIDIACARDS" -gt "0" ];then USENVIDIA=1; else echo "No NVIDIA cards detected"; fi

HEAVYFILESIZE=$(stat --printf="%s" heavy3.bin)
if [ $? -ne "0" ]; then
	HEAVYFILESIZE=0
fi

echo $HEAVYFILESIZE

if  [ "$USEAMD" -eq "1" ]  && [ "$USENVIDIA" -eq "1" ]  ;then
        echo "Have both AMD and NVIDIA"
        screen -dmS miner.nvidia stdbuf -oL -eL ./noncepool_miner $CONFIG_LINE | tee -a $CUSTOM_LOG_BASENAME.log
        if [ "$HEAVYFILESIZE" -ne "1073741824" ];then
                echo "Waiting for heavy3.bin file to be created"
                sleep 120
        fi
        stdbuf -oL -eL ./noncepool_miner_amd $CONFIG_LINE | tee -a $CUSTOM_LOG_BASENAME.log
else
        if [ "$USEAMD" -eq "1" ];then
                echo "Starting AMD Miner"
                stdbuf -oL -eL ./noncepool_miner_amd $CONFIG_LINE | tee -a $CUSTOM_LOG_BASENAME.log
        fi

        if [ "$USENVIDIA" -eq "1" ];then
                echo "Starting NVIDIA Miner"
                stdbuf -oL -eL ./noncepool_miner $CONFIG_LINE | tee -a $CUSTOM_LOG_BASENAME.log
        fi
fi

