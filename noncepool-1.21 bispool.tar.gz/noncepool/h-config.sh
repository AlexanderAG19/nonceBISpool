#!/usr/bin/env bash
#set -x

C10=$'\n';

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1

CUSTOM_ALGO=bismuth
config_address=$(sed  's/.*\(\S\{56\}\).*/\1/g' ${CUSTOM_CONFIG_FILENAME} )
config_worker=$(sed  's/.*\S\{56\}\s*\(\a*\)/\1/g' ${CUSTOM_CONFIG_FILENAME} )

if [[ -z $config_address ]] ;then
	conf="--hiveos ${CUSTOM_USER_CONFIG} ${CUSTOM_TEMPLATE} ${WORKER_NAME} ${C10}"
else
	[[ -z $config_worker ]] && config_worker="${WORKER_NAME}"
	conf="--hiveos ${CUSTOM_USER_CONFIG} ${config_address} ${config_worker} ${C10}"
fi
echo "$conf" > $CUSTOM_CONFIG_FILENAME
